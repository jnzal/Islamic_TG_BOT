from importers.duaa import duaa, duaaf
def duaa_chooser(constant): #IND
    return duaa[constant]

