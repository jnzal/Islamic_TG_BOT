from importers.quran import quran, countrf
def ayah_chooser(constant): #IND
    return quran[constant]

