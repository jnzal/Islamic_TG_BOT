from importers.hesn import hesn, hesnf
def hesn_chooser(constant): #IND
    text = "من كتاب حصن المسلم|" + hesn[constant]
    return text

