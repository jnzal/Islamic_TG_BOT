h = 3600
m = 60

my_id = 6166030174

ayah_repeater = 8
hesn_repeater = 12
duaa_repeater = 12
estiadah_repeater = 24
sunah_repeater = 12
nawawi_repeater = 24
azkar_mn_repeater = 12
