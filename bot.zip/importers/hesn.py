import pickle

with open("cont/hesn", "rb") as r:
    hesn = pickle.load(r)
hesnf = (len(hesn) - 1)
