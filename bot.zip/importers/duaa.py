import pickle

with open("cont/duaa", "rb") as r:
    duaa = pickle.load(r)
duaaf = len(duaa) - 1


